package com.data.model

data class PostResponse(
    val products: List<PostModel>
)
