package com.data.model

data class UploadResponse(
    val upload: List<PostModel>
)
