package com.ramm.models

class KlasifikasiViewModels {
}